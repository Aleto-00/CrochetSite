<style>
        body {
            background-color: #FFFACD; /* Jaune pastel */
            padding: 20px;
        }
    </style>

# Advanced crochet projects

Once you've mastered the basics, you can move on to more complex projects, such as blankets or garments.

Here are a few examples of advanced projects I've done. 

## Suggested projects

- **Plush on base** (_intermediate technique_)

<img src="../renard.jpg" alt="Image description" width="250"><img src="../elephant.jpg" alt=" Image description" width="250">  

  <img src="../renard & elephant.jpg" alt="Image description" width="300">  

- **Fictional characters** (_advanced technique_)

<img src="../neuvillette.jpg" alt="Image description" width="250"> <img src="../neuvillette2.jpg" alt="Image description" width="250">

<img src="../tartaglia.jpg" alt="Image description" width="250"> <img src="../tartaglia2.jpg" alt="Image description" width="250">

+ These characters come from a video game called genshin. They require much more time and technique, so I highly recommend starting with intermediate-level projects. It's an enriching and enjoyable experience!

> * 🪡Here is the list of equipment required:

> 1) Wool ball
>
> 2) Hook size 2.5-3 mm
> > ⚠️Faites always pay attention to the thickness of your wool. Hook size varies.
>
> 4) Markers
>
> 5) Hot glue gun


<style>
        body {
            color: #6F4C3E; /* Auburn color */
        }
    </style>


---

