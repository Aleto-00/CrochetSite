<style>
        body {
            background-color: #B2D8B2; /* Bleu pastel */
            font-family: Caveat, cursive;
            padding: 20px;
        }
    </style>

# Learn to crochet ✨

Welcome to my crochet website. You'll find information on how to get started, templates and tips.

**Everything here is handmade! :) Follow these tutorials to create your own projects!** There's something for every level, but this site is first and foremost a place for beginners to get started and enjoy themselves.

## About the hook 🧶

Crochet is a technique for creating textiles using a simple hook. There are endless patterns to explore!

> _Crocheting is a time-consuming art, but a very rewarding one._

* Follow me on Instagram for more inspiration.

* You can also follow my progress on vinted.

---

## Table of contents

1. [Beginner's guide](page2.md)
2. [Advanced projects](page3.md)

---
<style>
        }
        
        th, td {
            padding: 15px; /* Padding inside the cells */
            border: 1px solid #6F4C3E; /* Border color */
        }
        
        th {
            background-color: #D9EAD3; /* Light green for header */
        }
        
    </style>

### Hardware table

| Material | Description | --------------- | ------------------------------------ | | Hook | A 2.25mm hook is recommended for wool, but remember to vary sizes according to yarn thickness |  
| You can buy crochet markers, but a safety pin works just as well | | Small hot-glue guns are all you need. You can find them at cultura | | Sewing tape measure | If you ever want to work on a garment or a plea | 

![Alt text](https://scrapetbricodemonica.wordpress.com/wp-content/uploads/2021/01/astuces-et-conseils-pour-commencer-le-crochet.jpg)

 We're off! 😄
  
  <style>
        body {
            color: #6F4C3E; /* Auburn color */
        }
    </style>

